package com.heryad.foodplus;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResult;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.FirebaseDatabase;
import com.heryad.foodplus.App.CustomDialog;
import com.heryad.foodplus.App.KeyService;
import com.heryad.foodplus.App.MYSettings;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class SignUpActivity extends AppCompatActivity {

    EditText edtName;
    EditText edtLocation;
    Button btnCreate;

    CustomDialog customDialog;

    FirebaseDatabase db;

    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;

    protected static final String TAG = "LocationOnOff";
    private GoogleApiClient googleApiClient;
    final static int REQUEST_LOCATION = 199;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        edtName = findViewById(R.id.edt_signup_name);
        edtLocation = findViewById(R.id.edt_signup_location);
        btnCreate = findViewById(R.id.btn_signup_create);

        db = FirebaseDatabase.getInstance();

        Intent intent = getIntent();
        final String phoneNumber = intent.getStringExtra("phone");

        checkLocationPermission();

        // Todo Location Already on  ... start
        final LocationManager manager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
        if (manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            getCurrentLocation();
        }
        if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            enableLoc();
        }else{
            getCurrentLocation();
            Log.d("keshav","Gps already enabled");
        }

        btnCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String userName = edtName.getText().toString();
                if (TextUtils.isEmpty(userName)) {
                    customDialog = new CustomDialog(SignUpActivity.this);
                    customDialog.showInfoDialog(KeyService.INFO_ICON, "Please Fill Everything", "OK");
                } else {
                    addUserToDatabase(userName, phoneNumber);
                }
            }
        });
    }

    private void enableLoc() {
        if (googleApiClient == null) {
            googleApiClient = new GoogleApiClient.Builder(this)
                    .addApi(LocationServices.API)
                    .addConnectionCallbacks(new GoogleApiClient.ConnectionCallbacks() {
                        @Override
                        public void onConnected(Bundle bundle) {
                        }

                        @Override
                        public void onConnectionSuspended(int i) {
                            googleApiClient.connect();
                        }
                    })
                    .addOnConnectionFailedListener(new GoogleApiClient.OnConnectionFailedListener() {
                        @Override
                        public void onConnectionFailed(ConnectionResult connectionResult) {
                            Log.v("keshav","Location error " + connectionResult.getErrorCode());
                        }
                    }).build();
            googleApiClient.connect();

            LocationRequest locationRequest = LocationRequest.create();
            locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
            locationRequest.setInterval(30 * 1000);
            locationRequest.setFastestInterval(5 * 1000);
            LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder()
                    .addLocationRequest(locationRequest);

            builder.setAlwaysShow(true);

            PendingResult<LocationSettingsResult> result =
                    LocationServices.SettingsApi.checkLocationSettings(googleApiClient, builder.build());
            result.setResultCallback(new ResultCallback<LocationSettingsResult>() {
                @Override
                public void onResult(LocationSettingsResult result) {
                    final Status status = result.getStatus();
                    switch (status.getStatusCode()) {
                        case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:
                            try {
                                status.startResolutionForResult(SignUpActivity.this, REQUEST_LOCATION);
                            } catch (IntentSender.SendIntentException e) {
                                Log.v("keshav", e.getMessage());
                            }
                            break;
                    }
                }
            });
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_LOCATION: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    final LocationManager manager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
                    if (manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                        getCurrentLocation();
                    }
                    if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                        enableLoc();
                    }else{
                        getCurrentLocation();
                        Log.d("keshav","Gps already enabled");
                    }                } else {
                    checkLocationPermission();
                }
                return;
            }
        }
    }

    //checks to see if permission is enabled or not
    public void checkLocationPermission() {
        // Here, thisActivity is the current activity
        if (ContextCompat.checkSelfPermission(SignUpActivity.this,
                Manifest.permission.READ_CONTACTS)
                != PackageManager.PERMISSION_GRANTED) {
            // Permission is not granted
            // Should we show an explanation?
            if (ActivityCompat.shouldShowRequestPermissionRationale(SignUpActivity.this,
                    Manifest.permission.READ_CONTACTS)) {
                // Show an explanation to the user *asynchronously* -- don't block
                // this thread waiting for the user's response! After the user
                // sees the explanation, try again to request the permission.
            } else {
                // No explanation needed; request the permission
                ActivityCompat.requestPermissions(SignUpActivity.this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_LOCATION);

                // MY_PERMISSIONS_REQUEST_READ_CONTACTS is an
                // app-defined int constant. The callback method gets the
                // result of the request.
            }
        } else {
            getCurrentLocation();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_LOCATION && resultCode == RESULT_OK)
        {
            getCurrentLocation();
        }
        else if (requestCode == REQUEST_LOCATION && resultCode == RESULT_CANCELED)
        {
            final LocationManager manager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
            if (manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                getCurrentLocation();
            }
            if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                enableLoc();
            }else{
                getCurrentLocation();
                Log.d("keshav","Gps already enabled");
            }
        }
    }

    //gets current location
    private void getCurrentLocation() {
        LocationRequest mLocationRequest = LocationRequest.create();
        mLocationRequest.setInterval(60000);
        mLocationRequest.setFastestInterval(5000);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        LocationCallback mLocationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if (locationResult == null) {
                    return;
                }
                for (Location location : locationResult.getLocations()) {
                    if (location != null) {
                        getCityName(location.getLatitude(), location.getLongitude());
                    }
                }
            }
        };
        LocationServices.getFusedLocationProviderClient(SignUpActivity.this).requestLocationUpdates(mLocationRequest, mLocationCallback, null);
    }

    //gets current city name by using gps data
    private void getCityName(double mLat, double mLong) {
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        try {
            List<Address> addresses = geocoder.getFromLocation(mLat, mLong, 1);
            String cityName = addresses.get(0).getSubAdminArea();
            edtLocation.setText(cityName);
        } catch (IOException e) {
            Log.v("TAGGER", e.getMessage());
        }
    }


    private void addUserToDatabase(String userName, final String phoneNumber) {
        MYSettings MYSettings = new MYSettings(SignUpActivity.this);
        customDialog = new CustomDialog(SignUpActivity.this);
        customDialog.showLoadingDialog("Please Wait");
        Map<String, Object> dataMap = new HashMap<>();
        dataMap.put("userID", "CXHE");
        dataMap.put("userImageUrl", "");
        dataMap.put("userName", userName);
        dataMap.put("userPhoneNumber", phoneNumber);
        dataMap.put("userJoinDate", MYSettings.getCurrentTime());
        dataMap.put("userLocation", edtLocation.getText().toString());
        dataMap.put("userPhoneOs", MYSettings.getMobileOS());
        dataMap.put("userPhoneModel", MYSettings.getMobileModel());
        dataMap.put("userPhoneVersion", "Android : " + MYSettings.getMobileVersion());

        db.getReference().getRef().child("users")
                .child("erbil")
                .child(phoneNumber)
                .setValue(dataMap)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        customDialog.dissmisDialog();
                        Intent intent = new Intent(SignUpActivity.this, PhoneVerificationActivity.class);
                        intent.putExtra("phone", phoneNumber);
                        startActivity(intent);
                        finish();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        customDialog = new CustomDialog(SignUpActivity.this);
                        customDialog.showInfoDialog(KeyService.INFO_ICON, "Failed", "OK");
                    }
                });
    }
}
