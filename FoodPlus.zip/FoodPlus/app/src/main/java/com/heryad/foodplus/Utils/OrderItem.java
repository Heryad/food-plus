package com.heryad.foodplus.Utils;

public class OrderItem {

    private String itemID;
    private String foodName;
    private String foodPrice;

    public OrderItem(String foodName, String foodPrice, String itemID) {
        this.foodName = foodName;
        this.foodPrice = foodPrice;
        this.itemID = itemID;
    }

    public String getFoodName() {
        return foodName;
    }

    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    public String getFoodPrice() {
        return foodPrice;
    }

    public void setFoodPrice(String foodPrice) {
        this.foodPrice = foodPrice;
    }

    public String getItemID() {
        return itemID;
    }

    public void setItemID(String itemID) {
        this.itemID = itemID;
    }
}
