package com.heryad.foodplus;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResult;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.heryad.foodplus.App.CustomDialog;
import com.heryad.foodplus.App.KeyService;
import com.heryad.foodplus.App.NetworkDetector;
import com.heryad.foodplus.Database.DBHelper;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class SplashScreen extends AppCompatActivity {

    FirebaseUser firebaseUser;
    CustomDialog customDialog;
    public static final int MY_PERMISSIONS_REQUEST_LOCATION = 99;
    private GoogleApiClient googleApiClient;
    final static int REQUEST_LOCATION = 199;
    private LocationManager manager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
        checkLocationPermission();

         manager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);

        if (manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            //location already on
            getCurrentLocation();
        }
        if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            //location not on prompting a dialog
            enableLoc();
        } else {
            //already on
            getCurrentLocation();
        }
    }

    //enables location service by showing dialog
    private void enableLoc() {
        if (googleApiClient == null) {
            googleApiClient = new GoogleApiClient.Builder(this)
                    .addApi(LocationServices.API)
                    .addConnectionCallbacks(new GoogleApiClient.ConnectionCallbacks() {
                        @Override
                        public void onConnected(Bundle bundle) {
                        }

                        @Override
                        public void onConnectionSuspended(int i) {
                            googleApiClient.connect();
                        }
                    })
                    .addOnConnectionFailedListener(new GoogleApiClient.OnConnectionFailedListener() {
                        @Override
                        public void onConnectionFailed(ConnectionResult connectionResult) {
                            Log.v("keshav", "Location error " + connectionResult.getErrorCode());
                        }
                    }).build();
            googleApiClient.connect();

            LocationRequest locationRequest = LocationRequest.create();
            locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
            locationRequest.setInterval(30 * 1000);
            locationRequest.setFastestInterval(5 * 1000);
            LocationSettingsRequest.Builder builder = new LocationSettingsRequest.Builder()
                    .addLocationRequest(locationRequest);

            builder.setAlwaysShow(true);

            PendingResult<LocationSettingsResult> result =
                    LocationServices.SettingsApi.checkLocationSettings(googleApiClient, builder.build());
            result.setResultCallback(new ResultCallback<LocationSettingsResult>() {
                @Override
                public void onResult(LocationSettingsResult result) {
                    final Status status = result.getStatus();
                    switch (status.getStatusCode()) {
                        case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:
                            try {
                                status.startResolutionForResult(SplashScreen.this, REQUEST_LOCATION);
                            } catch (IntentSender.SendIntentException e) {
                                Log.v("keshav", e.getMessage());
                            }
                            break;
                    }
                }
            });
        }
    }

    //checks for location permissions
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_LOCATION: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    final LocationManager manager = (LocationManager) this.getSystemService(Context.LOCATION_SERVICE);
                    if (manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                        getCurrentLocation();
                    }
                    if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                        enableLoc();
                    } else {
                        getCurrentLocation();
                    }
                } else {
                    checkLocationPermission();
                }
                return;
            }
        }
    }

    //checks to see if permission is enabled or not
    public void checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(SplashScreen.this,
                Manifest.permission.READ_CONTACTS)
                != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(SplashScreen.this,
                    Manifest.permission.READ_CONTACTS)) {
            } else {
                ActivityCompat.requestPermissions(SplashScreen.this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        MY_PERMISSIONS_REQUEST_LOCATION);
            }
        } else {
            getCurrentLocation();
        }
    }

    //handles the location dialog answer
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_LOCATION && resultCode == RESULT_OK) {
            getCurrentLocation();
        }
        if (resultCode == 0)
        {
            enableLoc();
        }
    }

    //gets current location in long and lat
    private void getCurrentLocation() {
        LocationRequest mLocationRequest = LocationRequest.create();
        mLocationRequest.setInterval(60000);
        mLocationRequest.setFastestInterval(5000);
        mLocationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);
        LocationCallback mLocationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if (locationResult == null) {
                    return;
                }
                for (Location location : locationResult.getLocations()) {
                    if (location != null) {
                        getCityName(location.getLatitude(), location.getLongitude());
                    }
                }
            }
        };
        LocationServices.getFusedLocationProviderClient(SplashScreen.this).requestLocationUpdates(mLocationRequest, mLocationCallback, null);
    }

    //gets current city name by using long and lat
    private void getCityName(double mLat, double mLong) {
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        try {
            List<Address> addresses = geocoder.getFromLocation(mLat, mLong, 1);
            String cityName = addresses.get(0).getSubAdminArea();
            openNextActivity(cityName);
        } catch (IOException e) {
            Log.v("TAGGER", e.getMessage());
        }
    }

    //navigates the user to next activity
    private void openNextActivity(String cityName) {
        DBHelper dbHelper = new DBHelper(SplashScreen.this);
        if (cityName.equals("Erbil")) {
            dbHelper.addLocation("erbil");
        } else if (cityName.equals("Sulaymaniyah")) {
            dbHelper.addLocation("suli");
        }
        NetworkDetector networkDetector = new NetworkDetector(this);
        if (networkDetector.isOnline()) {
            new Handler().postDelayed(new Runnable() {
                @Override
                public void run() {
                    firebaseUser = FirebaseAuth.getInstance().getCurrentUser();
                    if (firebaseUser == null) {
                        Intent intent = new Intent(SplashScreen.this, PhoneEntryActivity.class);
                        startActivity(intent);
                        finish();
                    } else {
                        Intent intent = new Intent(SplashScreen.this, MainActivity.class);
                        startActivity(intent);
                        finish();
                    }
                }
            }, 1000);
        } else {
            customDialog = new CustomDialog(SplashScreen.this);
            customDialog.showInfoDialog(KeyService.INFO_ICON, "Please Check Internet Connection", "OK");
        }
    }
}
