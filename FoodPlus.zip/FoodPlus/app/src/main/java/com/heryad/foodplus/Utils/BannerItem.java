package com.heryad.foodplus.Utils;

public class BannerItem {

    private String imgUrl;
    private String mValue;
    private String mPurpose;

    public BannerItem(String imgUrl, String mValue, String mPurpose) {
        this.imgUrl = imgUrl;
        this.mValue = mValue;
        this.mPurpose = mPurpose;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getmValue() {
        return mValue;
    }

    public void setmValue(String mValue) {
        this.mValue = mValue;
    }

    public String getmPurpose() {
        return mPurpose;
    }

    public void setmPurpose(String mPurpose) {
        this.mPurpose = mPurpose;
    }
}
