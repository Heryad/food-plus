package com.heryad.foodplus.Fragments;


import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.heryad.foodplus.Adapters.BasketAdapter;
import com.heryad.foodplus.Database.DBHelper;
import com.heryad.foodplus.OrderActivity;
import com.heryad.foodplus.R;
import com.heryad.foodplus.Utils.BasketItem;

import java.util.ArrayList;
import java.util.List;


public class BasketFragment extends Fragment implements BasketAdapter.EventListener {


    private List<BasketItem> restList;
    private RecyclerView recyclerView;
    private BasketAdapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    public Button btnOrder;

    public BasketFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_basket, container, false);

        recyclerView = rootView.findViewById(R.id.basketList);
        layoutManager = new LinearLayoutManager(getContext());
        btnOrder = rootView.findViewById(R.id.btnOrder);

        fetchData();

        btnOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DBHelper dbHelper = new DBHelper(getContext());
                Cursor cursor = dbHelper.getCartItems();
                while (cursor.moveToNext()) {
                    String restName = cursor.getString(1);
                    Intent intent = new Intent(getContext(), OrderActivity.class);
                    intent.putExtra("name", restName);
                    startActivity(intent);
                }
            }
        });

        return rootView;
    }

    //gets all ordered items from sqlite to listview
    private void fetchData() {
        try {
            restList = new ArrayList<>();

            DBHelper dbHelper = new DBHelper(getContext());
            Cursor cursor = dbHelper.getCart();

            if (cursor.getCount() == 0) {
                btnOrder.setText("Empty Cart");
                btnOrder.setBackgroundColor(Color.parseColor("#FF9C2E24"));
                btnOrder.setEnabled(false);
            } else {
                btnOrder.setText(getContext().getResources().getString(R.string.btn_complete_order));
                btnOrder.setBackgroundColor(Color.parseColor("#e34234"));
                btnOrder.setEnabled(true);
                while (cursor.moveToNext()) {
                    int itemID = cursor.getInt(0);
                    String restName = cursor.getString(1);
                    String foodName = cursor.getString(2);
                    String foodPrice = cursor.getString(3);
                    String foodURL = cursor.getString(4);

                    restList.add(new BasketItem(restName, foodName, foodPrice, foodURL, String.valueOf(itemID)));
                    adapter = new BasketAdapter(getContext(), restList, this);
                    recyclerView.setLayoutManager(layoutManager);
                    recyclerView.setAdapter(adapter);
                }
            }
        } catch (Exception c) {
        }

    }

    //retrieves the delete void in adapter to check if the cart is empty or not
    public void onEvent() {
        try {
            DBHelper dbHelper = new DBHelper(getContext());
            Cursor cursor = dbHelper.getCart();
            if (cursor.getCount() == 0) {
                btnOrder.setText("Empty Cart");
                btnOrder.setBackgroundColor(Color.parseColor("#FF9C2E24"));
                btnOrder.setEnabled(false);
            } else {
                btnOrder.setText(getContext().getResources().getString(R.string.btn_complete_order));
                btnOrder.setBackgroundColor(Color.parseColor("#e34234"));
                btnOrder.setEnabled(true);
            }

        } catch (Exception c) {
        }
    }

}
