package com.heryad.foodplus;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.MenuItem;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.heryad.foodplus.Fragments.BasketFragment;
import com.heryad.foodplus.Fragments.DriverFragment;
import com.heryad.foodplus.Fragments.HomeFragment;
import com.heryad.foodplus.Fragments.ProfileFragment;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        BottomNavigationView navView = findViewById(R.id.nav_view);
        navView.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        Intent intent = getIntent();
        String mID = intent.getStringExtra("id");
        if (TextUtils.isEmpty(mID)) {
            HomeFragment homeFragment = new HomeFragment();
            swapFragment(homeFragment);
        }
        if (!TextUtils.isEmpty(mID) && mID.equals("basket")) {
            View view = navView.findViewById(R.id.btnBasket);
            view.performClick();
        }
    }

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {

                case R.id.btnHome:
                    HomeFragment homeFragment = new HomeFragment();
                    swapFragment(homeFragment);
                    return true;
                case R.id.btnBasket:
                    BasketFragment basketFragment = new BasketFragment();
                    swapFragment(basketFragment);
                    return true;
                case R.id.btnDriver:
                    DriverFragment driverFragment = new DriverFragment();
                    swapFragment(driverFragment);
                    return true;
                case R.id.btnProfile:
                    ProfileFragment profileFragment = new ProfileFragment();
                    swapFragment(profileFragment);
                    return true;
            }
            return false;
        }
    };

    private void swapFragment(Fragment fragment) {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.frameLayout, fragment, "FRAG");
        fragmentTransaction.commit();
    }

    @Override
    public void onBackPressed() {

    }
}
