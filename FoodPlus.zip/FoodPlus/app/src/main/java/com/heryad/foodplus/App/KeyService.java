package com.heryad.foodplus.App;

public class KeyService {
    public static String TAG = "LOGGED";
    public static String INFO_ICON = "https://www.pinclipart.com/picdir/middle/255-2550760_more-info-icon-free-png-and-svg-download.png";
    public static int minOrder;
}
