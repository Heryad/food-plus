package com.heryad.foodplus;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseException;
import com.google.firebase.FirebaseTooManyRequestsException;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;
import com.heryad.foodplus.App.CustomDialog;
import com.heryad.foodplus.App.KeyService;
import com.heryad.foodplus.App.MYSettings;

import java.util.concurrent.TimeUnit;

public class PhoneVerificationActivity extends AppCompatActivity {

    Button btnVerify;
    Button btnResend;

    EditText edtCode;

    FirebaseAuth mAuth;
    private PhoneAuthProvider.ForceResendingToken mResendToken;
    private PhoneAuthProvider.OnVerificationStateChangedCallbacks mCallBacks;
    String mVerificationId;

    CustomDialog customDialog;

    private String mNum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phone_verification);

        btnVerify = findViewById(R.id.btnVerify);
        btnResend = findViewById(R.id.btnResend);
        edtCode = findViewById(R.id.edtCode);

        Intent intent = getIntent();
        final String phoneNumber = intent.getStringExtra("phone");
        mNum = phoneNumber;

        btnResend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                resendVerificationCode(phoneNumber, mResendToken);
            }
        });

        btnVerify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TextUtils.isEmpty(edtCode.getText().toString())) {
                    customDialog = new CustomDialog(PhoneVerificationActivity.this);
                    customDialog.showInfoDialog(KeyService.INFO_ICON, PhoneVerificationActivity.this.getResources().getString(R.string.lbl_verification), PhoneVerificationActivity.this.getResources().getString(R.string.btn_ok));
                } else {
                    verifyPhoneNumberWithCode(mVerificationId, edtCode.getText().toString());
                }
            }
        });
        initFirebase();
        verifyNumber(phoneNumber);
    }

    //verifies the entered phone number
    private void verifyNumber(String mNumber) {
        PhoneAuthProvider.getInstance().verifyPhoneNumber(
                "+964" + mNumber,
                60,
                TimeUnit.SECONDS,
                this,
                mCallBacks);
    }

    //resends the code
    private void resendVerificationCode(String phoneNumber, PhoneAuthProvider.ForceResendingToken token) {
        PhoneAuthProvider.getInstance().verifyPhoneNumber("+964" + phoneNumber, 60, TimeUnit.SECONDS, this, mCallBacks, token);
    }

    //signs in the use manually by entering the code
    private void verifyPhoneNumberWithCode(String verificationId, String code) {
        try {
            PhoneAuthCredential credential = PhoneAuthProvider.getCredential(verificationId, code);
            signIn(credential);
        } catch (Exception c) {
        }

    }

    //signs in the user and opens MainActivity
    private void signIn(PhoneAuthCredential credential) {
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            MYSettings helper = new MYSettings(PhoneVerificationActivity.this);
                            helper.savePhone(mNum);
                            Intent intent = new Intent(PhoneVerificationActivity.this, MainActivity.class);
                            startActivity(intent);
                            finish();
                        }
                        Log.w("HANGOVER", "signInWithCredential:failure", task.getException());
                        if (task.getException() instanceof FirebaseAuthInvalidCredentialsException) {
                            customDialog = new CustomDialog(PhoneVerificationActivity.this);
                            customDialog.showInfoDialog(KeyService.INFO_ICON, PhoneVerificationActivity.this.getResources().getString(R.string.msg_wrong_code), PhoneVerificationActivity.this.getResources().getString(R.string.btn_ok));
                        }
                    }
                });
    }

    //inits firebase settings
    private void initFirebase() {
        mAuth = FirebaseAuth.getInstance();

        mCallBacks = new PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
            @Override
            public void onVerificationCompleted(PhoneAuthCredential phoneAuthCredential) {
                signIn(phoneAuthCredential);
            }

            @Override
            public void onVerificationFailed(FirebaseException e) {
                if (e instanceof FirebaseTooManyRequestsException) {
                }
                Log.d("Error", e.getMessage().toLowerCase());
            }

            @Override
            public void onCodeSent(String s, PhoneAuthProvider.ForceResendingToken forceResendingToken) {
                mVerificationId = s;
                mResendToken = forceResendingToken;
            }
        };
    }

    @Override
    public void onBackPressed() {

    }
}
