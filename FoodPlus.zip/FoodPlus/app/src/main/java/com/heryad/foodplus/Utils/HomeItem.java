package com.heryad.foodplus.Utils;

public class HomeItem {
    private String imgUrl;
    private String restName;
    private String deliveryTime;
    private String minOrder;
    private String workingHours;

    public HomeItem(String imgUrl, String restName, String deliveryTime, String minOrder, String workingHours) {
        this.imgUrl = imgUrl;
        this.restName = restName;
        this.deliveryTime = deliveryTime;
        this.minOrder = minOrder;
        this.workingHours = workingHours;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getRestName() {
        return restName;
    }

    public void setRestName(String restName) {
        this.restName = restName;
    }

    public String getDeliveryTime() {
        return deliveryTime;
    }

    public void setDeliveryTime(String deliveryTime) {
        this.deliveryTime = deliveryTime;
    }

    public String getMinOrder() {
        return minOrder;
    }

    public void setMinOrder(String minOrder) {
        this.minOrder = minOrder;
    }

    public String getWorkingHours() {
        return workingHours;
    }

    public void setWorkingHours(String workingHours) {
        this.workingHours = workingHours;
    }
}
