package com.heryad.foodplus.Utils;

public class CategoryItem {
    private String restName;
    private String imageUrl;
    private String categoryTitle;

    public CategoryItem(String restName, String imageUrl, String categoryTitle) {
        this.restName = restName;
        this.imageUrl = imageUrl;
        this.categoryTitle = categoryTitle;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getCategoryTitle() {
        return categoryTitle;
    }

    public void setCategoryTitle(String categoryTitle) {
        this.categoryTitle = categoryTitle;
    }

    public String getRestName() {
        return restName;
    }

    public void setRestName(String restName) {
        this.restName = restName;
    }
}
