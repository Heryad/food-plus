package com.heryad.foodplus;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.heryad.foodplus.Adapters.CategoryListAdapter;
import com.heryad.foodplus.Utils.CategoryItem;

import java.util.ArrayList;
import java.util.List;

public class CategoryActivity extends AppCompatActivity {

    FirebaseDatabase db;

    ImageView imgRest;
    TextView txtTitle, txtMinOrder;

    List<CategoryItem> catList;
    RecyclerView recyclerView;
    CategoryListAdapter adapter;
    ProgressBar prg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);

        imgRest = findViewById(R.id.imgCategoryTitle);
        txtTitle = findViewById(R.id.txtCategoryRestName);
        txtMinOrder = findViewById(R.id.txtCategoryMinOrder);
        recyclerView = findViewById(R.id.categoryList);
        prg = findViewById(R.id.prgCategory);

        db = FirebaseDatabase.getInstance();

        Intent intent = getIntent();
        String restaurantName = intent.getStringExtra("name");

        fetchDta(restaurantName);
    }

    //gets the res name and min order
    private void fetchDta(final String mResName) {
        db.getReference().getRef().child("restaurants")
                .child("erbil")
                .child(mResName)
                .addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot task) {

                Glide.with(CategoryActivity.this).load(task.child("url").getValue().toString()).into(imgRest);
                txtTitle.setText(task.child("restName").getValue().toString().toUpperCase());
                txtMinOrder.setText(getResources().getString(R.string.lbl_min_order)
                        + " " + task.child("minOrder").getValue().toString()
                        + " IQD");
                getCategory(mResName);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    //gets all the category of this restaurant
    private void getCategory(final String mResName) {
        catList = new ArrayList<>();
        prg.setVisibility(View.VISIBLE);
        db.getReference().getRef().child("restaurants")
                .child("erbil")
                .child(mResName)
                .child("category").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot result : dataSnapshot.getChildren()) {
                    String imgURL = result.child("url").getValue().toString();
                    String categoryTitle = result.child("catName").getValue().toString();
                    catList.add(new CategoryItem(mResName, imgURL, categoryTitle));

                    adapter = new CategoryListAdapter(CategoryActivity.this, catList);
                    recyclerView.setLayoutManager(new GridLayoutManager(CategoryActivity.this, 2));
                    recyclerView.setAdapter(adapter);
                }
                prg.setVisibility(View.GONE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }
}
