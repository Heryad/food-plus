package com.heryad.foodplus.Database;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DBHelper extends SQLiteOpenHelper {

    private Context mContext;

    //Database
    private static String DB_NAME = "database.db";
    private static int DB_VERSION = 22;

    //Table orders (basket)
    private static String TABLE_ORDERS = "orders";
    private static String ID = "id";
    private static String REST_NAME = "rest_name";
    private static String FOOD_NAME = "food_name";
    private static String FOOD_PRICE = "food_price";
    private static String FOOD_URL = "food_url";
    private static String TABLE_ORDERS_COMMAND = "CREATE TABLE " + TABLE_ORDERS
            + " (" + ID + " INTEGER PRIMARY KEY,"
            + REST_NAME + " TEXT,"
            + FOOD_NAME + " TEXT,"
            + FOOD_PRICE + " TEXT,"
            + FOOD_URL + " TEXT"
            + ")";

    //table location
    private static String TABLE_LOCATION = "location";
    private static String mID = "id";
    private static String CITY_NAME = "city_name";
    private static String TABLE_LOCATION_COMMAND = "CREATE TABLE " + TABLE_LOCATION
            + " (" + mID + " INTEGER PRIMARY KEY,"
            + CITY_NAME + " TEXT"
            + ")";


    public DBHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
        this.mContext = context;
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(TABLE_ORDERS_COMMAND);
        db.execSQL(TABLE_LOCATION_COMMAND);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ORDERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_LOCATION);
    }

    public void addFood(String mRestName, String mFoodName, String mFoodPrice, String mFoodURL) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();

        contentValues.put(REST_NAME, mRestName);
        contentValues.put(FOOD_NAME, mFoodName);
        contentValues.put(FOOD_PRICE, mFoodPrice);
        contentValues.put(FOOD_URL, mFoodURL);

        db.insert(TABLE_ORDERS, null, contentValues);
        db.close();
    }

    // get all items in the cart
    public Cursor getCart() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from orders", null);
        return cursor;
    }

    // returns the items in the cart by limiting to show only 1 item
    public Cursor getCartItems() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from orders limit 1", null);
        return cursor;
    }

    public void deleteItem(String mID) {
        SQLiteDatabase db = this.getWritableDatabase();

        String mCommand = "DELETE FROM orders WHERE id = " + mID;
        db.execSQL(mCommand);
        db.close();
    }

    public void clearBasket() {
        SQLiteDatabase db = this.getWritableDatabase();

        String mCommand = "DELETE FROM orders";
        db.execSQL(mCommand);
        db.close();
    }

    public void addLocation(String cityName) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues contentValues = new ContentValues();

        contentValues.put(CITY_NAME, cityName);

        db.insert(TABLE_LOCATION, null, contentValues);
        db.close();
    }

    public Cursor getLocation() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from location limit 1", null);
        return cursor;
    }
}
