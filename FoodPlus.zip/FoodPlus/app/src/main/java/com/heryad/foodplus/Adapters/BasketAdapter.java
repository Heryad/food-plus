package com.heryad.foodplus.Adapters;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.heryad.foodplus.Database.DBHelper;
import com.heryad.foodplus.Fragments.BasketFragment;
import com.heryad.foodplus.R;
import com.heryad.foodplus.Utils.BasketItem;

import java.util.List;

public class BasketAdapter extends RecyclerView.Adapter<BasketAdapter.DataViewHolder> {

    private Context mContext;
    private List<BasketItem> itemList;
    EventListener listener;

    public BasketAdapter(Context mContext, List<BasketItem> itemList, EventListener listener) {
        this.mContext = mContext;
        this.itemList = itemList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public BasketAdapter.DataViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(
                R.layout.list_item_basket, parent, false);
        return new BasketAdapter.DataViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final BasketAdapter.DataViewHolder holder, final int position) {
        Glide.with(mContext).load(itemList.get(position).getImgURL()).into(holder.imgTitle);

        holder.txtFoodTitle.setText(itemList.get(position).getFoodName().toUpperCase());
        holder.txtFoodPrice.setText(mContext.getResources().getString(R.string.lbl_price)
                + " " + itemList.get(position).getFoodPrice());

        holder.btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DBHelper dbHelper = new DBHelper(mContext);
                dbHelper.deleteItem(itemList.get(position).getItemID());
                itemList.remove(position);
                notifyDataSetChanged();
                listener.onEvent();
            }
        });
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    public interface EventListener {
        void onEvent();
    }

    public class DataViewHolder extends RecyclerView.ViewHolder {

        ImageView imgTitle;
        TextView txtFoodTitle;
        TextView txtFoodPrice;
        Button btnDelete;

        public DataViewHolder(@NonNull View itemView) {
            super(itemView);
            imgTitle = itemView.findViewById(R.id.lst_basket_img);
            txtFoodTitle = itemView.findViewById(R.id.lst_basket_title);
            txtFoodPrice = itemView.findViewById(R.id.lst_basket_price);
            btnDelete = itemView.findViewById(R.id.btn_basket_delete);
        }
    }
}
