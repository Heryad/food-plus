package com.heryad.foodplus.Utils;

public class BasketItem {
    private String itemID;
    private String restName;
    private String foodName;
    private String foodPrice;
    private String imgURL;

    public BasketItem(String restName, String foodName, String foodPrice, String imgURL, String itemID) {
        this.restName = restName;
        this.foodName = foodName;
        this.foodPrice = foodPrice;
        this.imgURL = imgURL;
        this.itemID = itemID;
    }

    public String getRestName() {
        return restName;
    }

    public void setRestName(String restName) {
        this.restName = restName;
    }

    public String getFoodName() {
        return foodName;
    }

    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    public String getFoodPrice() {
        return foodPrice;
    }

    public void setFoodPrice(String foodPrice) {
        this.foodPrice = foodPrice;
    }

    public String getImgURL() {
        return imgURL;
    }

    public void setImgURL(String imgURL) {
        this.imgURL = imgURL;
    }

    public String getItemID() {
        return itemID;
    }

    public void setItemID(String itemID) {
        this.itemID = itemID;
    }
}
