package com.heryad.foodplus.Adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.heryad.foodplus.CategoryActivity;
import com.heryad.foodplus.R;
import com.heryad.foodplus.SubCategoryActivity;
import com.heryad.foodplus.Utils.CategoryItem;
import com.heryad.foodplus.Utils.HomeItem;

import java.util.List;

public class CategoryListAdapter extends RecyclerView.Adapter<CategoryListAdapter.DataViewHolder> {

    private Context mContext;
    private List<CategoryItem> itemList;

    public CategoryListAdapter(Context mContext, List<CategoryItem> itemList) {
        this.mContext = mContext;
        this.itemList = itemList;
    }

    @NonNull
    @Override
    public CategoryListAdapter.DataViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(
                R.layout.list_item_category, parent, false);
        return new CategoryListAdapter.DataViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CategoryListAdapter.DataViewHolder holder, final int position) {
        Glide.with(mContext).load(itemList.get(position).getImageUrl()).into(holder.imgTitle);

        holder.txtCategoryTitle.setText(itemList.get(position).getCategoryTitle().toUpperCase());

        holder.layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(mContext, SubCategoryActivity.class);
                intent.putExtra("name", itemList.get(position).getRestName());
                intent.putExtra("category", itemList.get(position).getCategoryTitle());
                mContext.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    public class DataViewHolder extends RecyclerView.ViewHolder {

        LinearLayout layout;
        ImageView imgTitle;
        TextView txtCategoryTitle;

        public DataViewHolder(@NonNull View itemView) {
            super(itemView);
            layout = itemView.findViewById(R.id.lst_category);
            imgTitle = itemView.findViewById(R.id.lst_category_img);
            txtCategoryTitle = itemView.findViewById(R.id.lst_category_title);

        }
    }
}
