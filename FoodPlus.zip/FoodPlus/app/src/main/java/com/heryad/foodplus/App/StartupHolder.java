package com.heryad.foodplus.App;

import android.content.Context;

import com.google.firebase.database.FirebaseDatabase;

public class StartupHolder {
    private Context mContext;
    private FirebaseDatabase db;
    public StartupHolder(Context mContext) {
        this.mContext = mContext;

    }

    public void getData()
    {

    }

}
