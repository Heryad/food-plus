package com.heryad.foodplus.App;

import android.content.Context;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.heryad.foodplus.R;

public class CustomDialog {

    private Context mContext;
    android.app.Dialog dialog;

    public CustomDialog(Context mContext) {
        this.mContext = mContext;
    }

    public void showInfoDialog(String imgTitle, String mDetail, String btnText) {

        dialog = new android.app.Dialog(mContext);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.dialog);
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        ImageView imageView = dialog.findViewById(R.id.dialogImg);
        Glide.with(mContext).load(imgTitle).into(imageView);

        TextView text = dialog.findViewById(R.id.dialogDetail);
        text.setText(mDetail);

        Button dialogButton = dialog.findViewById(R.id.dialogOK);
        dialogButton.setText(btnText);
        dialogButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
            }
        });

        dialog.show();
    }

    public void showLoadingDialog(String mDetail) {

        dialog = new android.app.Dialog(mContext);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setCancelable(false);
        dialog.setContentView(R.layout.dialog);
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

        ImageView imageView = dialog.findViewById(R.id.dialogImg);
        imageView.setVisibility(View.GONE);

        ProgressBar progressBar = dialog.findViewById(R.id.dialogProgress);
        progressBar.setVisibility(View.VISIBLE);
        TextView text = dialog.findViewById(R.id.dialogDetail);
        text.setText(mDetail);

        Button dialogButton = dialog.findViewById(R.id.dialogOK);
        dialogButton.setVisibility(View.GONE);

        dialog.show();
    }


    public void dissmisDialog() {
        dialog.dismiss();
    }
}
