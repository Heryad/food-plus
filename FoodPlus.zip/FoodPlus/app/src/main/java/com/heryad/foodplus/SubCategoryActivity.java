package com.heryad.foodplus;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.heryad.foodplus.Adapters.SubCategoryListAdapter;
import com.heryad.foodplus.Database.DBHelper;
import com.heryad.foodplus.Utils.SubCategoryItem;

import java.util.ArrayList;
import java.util.FormatFlagsConversionMismatchException;
import java.util.List;

public class SubCategoryActivity extends AppCompatActivity implements SubCategoryListAdapter.EventListener {


    List<SubCategoryItem> subCatList;
    RecyclerView recyclerView;
    SubCategoryListAdapter adapter;
    private RecyclerView.LayoutManager layoutManager;
    ProgressBar prg;
    Button btnBasket;
    TextView txtTitle;

    FirebaseDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub_category);

        recyclerView = findViewById(R.id.subcategoryList);
        prg = findViewById(R.id.prgSubCategory);
        btnBasket = findViewById(R.id.btnOpenBasket);
        txtTitle = findViewById(R.id.txtSubCategoryTitle);

        db = FirebaseDatabase.getInstance();

        layoutManager = new LinearLayoutManager(this);

        final Intent intent = getIntent();
        final String restName = intent.getStringExtra("name");
        String itemCategory = intent.getStringExtra("category");

        txtTitle.setText(itemCategory.toUpperCase());

        fetchData(restName, itemCategory);

        btnBasket.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent finishOrder = new Intent(SubCategoryActivity.this, OrderActivity.class);
                finishOrder.putExtra("name", restName);
                startActivity(finishOrder);
            }
        });

        DBHelper dbHelper = new DBHelper(SubCategoryActivity.this);
        Cursor cursor = dbHelper.getCart();
        if (cursor.getCount() == 0) {
            btnBasket.setVisibility(View.GONE);
        } else {
            btnBasket.setVisibility(View.VISIBLE);
        }
    }

    //gets all the sub category items into the listview
    private void fetchData(final String mResName, String mCatName) {
        subCatList = new ArrayList<>();
        prg.setVisibility(View.VISIBLE);
        db.getReference().getRef().child("restaurants")
                .child(getCityName())
                .child(mResName)
                .child("category")
                .child(mCatName)
                .child("subCategory")
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot ds) {
                        for (DataSnapshot result : ds.getChildren()) {
                            String imgUrl = result.child("url").getValue().toString();
                            String itemTitle = result.child("itemName").getValue().toString();
                            String itemPrice = result.child("itemPrice").getValue().toString();

                            subCatList.add(new SubCategoryItem(imgUrl, itemTitle, itemPrice, mResName));

                            adapter = new SubCategoryListAdapter(SubCategoryActivity.this, subCatList, SubCategoryActivity.this);
                            recyclerView.setLayoutManager(layoutManager);
                            recyclerView.setAdapter(adapter);
                            prg.setVisibility(View.GONE);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
    }

    @Override
    public void onEvent() {
        DBHelper dbHelper = new DBHelper(SubCategoryActivity.this);
        Cursor cursor = dbHelper.getCart();
        if (cursor.getCount() == 0) {
            btnBasket.setVisibility(View.GONE);
        } else {
            btnBasket.setVisibility(View.VISIBLE);
        }
    }

    public String getCityName() {
        DBHelper dbHelper = new DBHelper(SubCategoryActivity.this);
        Cursor cursor = dbHelper.getLocation();
        String cityName = "";
        if (cursor.getCount() != 0) {
            while (cursor.moveToNext()) {
                cityName = cursor.getString(1);
            }
        }
        return cityName;
    }
}
