package com.heryad.foodplus;

import android.content.Intent;
import android.database.Cursor;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.heryad.foodplus.Adapters.OrderAdapter;
import com.heryad.foodplus.App.KeyService;
import com.heryad.foodplus.Database.DBHelper;
import com.heryad.foodplus.Utils.OrderItem;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class OrderActivity extends AppCompatActivity {

    FirebaseDatabase db;

    private TextView txtSubTotal;
    private TextView txtDeliveryFee;
    private TextView txtTotalWorth;
    private ListView listView;
    private Button btnOrder;
    private ArrayList<OrderItem> foodList;
    private OrderAdapter adapter;
    private EditText edtAreName, edtAreaExtraInfo;
    private FusedLocationProviderClient client;


    int totalFoodPrice;
    int deliveryFee;
    int totalWorth;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);

        listView = findViewById(R.id.orderList);
        txtSubTotal = findViewById(R.id.txtSubTotal);
        txtDeliveryFee = findViewById(R.id.txtDeliveryFee);
        txtTotalWorth = findViewById(R.id.txtTotalWorth);
        btnOrder = findViewById(R.id.btnFinishOrder);
        edtAreName = findViewById(R.id.edtAreaName);
        edtAreaExtraInfo = findViewById(R.id.edtAreaExtra);
        client = LocationServices.getFusedLocationProviderClient(this);

        Intent intent = getIntent();
        final String restName = intent.getStringExtra("name");

        db = FirebaseDatabase.getInstance();

        fetchData();

        btnOrder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkMinOrder(restName);
            }
        });
    }


    private void fetchData() {
        try {
            foodList = new ArrayList<>();

            DBHelper dbHelper = new DBHelper(OrderActivity.this);
            Cursor cursor = dbHelper.getCart();

            while (cursor.moveToNext()) {
                String itemID = cursor.getString(0);
                String foodName = cursor.getString(2);
                String foodPrice = cursor.getString(3);

                foodList.add(new OrderItem(foodName, foodPrice, itemID));
                adapter = new OrderAdapter(OrderActivity.this, foodList);
                listView.setAdapter(adapter);

            }
        } catch (Exception c) {
            Log.v(KeyService.TAG, c.getMessage());
        }
        calculateFee();
    }

    private void calculateFee() {
        DBHelper dbHelper = new DBHelper(OrderActivity.this);
        Cursor cursor = dbHelper.getCart();
        if (cursor.getCount() != 0) {
            while (cursor.moveToNext()) {
                String foodPrice = cursor.getString(3);
                totalFoodPrice += Integer.parseInt(foodPrice);
                txtSubTotal.setText(this.getResources().getString(R.string.lbl_sub_total) + " " + totalFoodPrice + " IQD");
            }
        }
        getDeliveryPrice();
    }

    private void checkMinOrder(String restName) {
        db.getReference().getRef().child("restaurants")
                .child("erbil")
                .child(restName).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot task) {
                int minOrder = Integer.parseInt(task.child("minOrder").getValue().toString());
                if (totalFoodPrice >= minOrder) {
                    Toast.makeText(OrderActivity.this, "Order Success", Toast.LENGTH_SHORT).show();

                } else {
                    Toast.makeText(OrderActivity.this, "min order issue", Toast.LENGTH_SHORT).show();

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    //gets current city name by using gps data
    private void getLocationInfo(double mLat, double mLong) {
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        try {
            List<Address> addresses = geocoder.getFromLocation(mLat, mLong, 1);
            String cityName = addresses.get(0).getSubAdminArea();
            String areaName = addresses.get(0).getFeatureName();
            edtAreName.setText("  " + cityName + ", " + areaName);
        } catch (IOException e) {
            Log.v("TAGGER", e.getMessage());
        }
    }

    private void getDeliveryPrice() {
        db.getReference().getRef()
                .child("system")
                .child("startup")
                .child("deliveryPrices")
                .child(getCityName())
                .addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.exists()) {
                            String normalDelivery = dataSnapshot.child("normalPrice").getValue().toString();
                            txtDeliveryFee.setText(OrderActivity.this.getResources().getString(R.string.lbl_delivery) + " " + normalDelivery);
                            String i = normalDelivery.replace(" IQD", "");
                            calculateTotal(totalFoodPrice, Integer.parseInt(i));
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
    }

    public String getCityName() {
        DBHelper dbHelper = new DBHelper(this);
        Cursor cursor = dbHelper.getLocation();
        String cityName = "";
        if (cursor.getCount() != 0) {
            while (cursor.moveToNext()) {
                cityName = cursor.getString(1);
            }
        }
        return cityName;
    }

    private void calculateTotal(int totalFood, int mDelivery) {
        int finalPrice = totalFood + mDelivery;
        txtTotalWorth.setText(this.getString(R.string.lbl_total) + " " + String.valueOf(finalPrice));
    }
}
