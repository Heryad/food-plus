package com.heryad.foodplus.App;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.text.TextUtils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import static android.content.Context.MODE_PRIVATE;

public class MYSettings {

    private Context mContext;

    public MYSettings(Context mContext) {
        this.mContext = mContext;
    }

    public String getMobileVersion() {
        return Build.VERSION.RELEASE;
    }

    public String getMobileOS() {
        return "Android";
    }

    public String getMobileModel() {
        String manufacturer = Build.MANUFACTURER;
        String model = Build.MODEL;
        if (model.startsWith(manufacturer)) {
            return capitalize(model);
        }
        return capitalize(manufacturer) + " " + model;
    }

    public String getCurrentTime() {
        DateFormat df = new SimpleDateFormat("EEE, d MMM yyyy, HH:mm");
        return df.format(Calendar.getInstance().getTime());
    }

    private String capitalize(String str) {
        if (TextUtils.isEmpty(str)) {
            return str;
        }
        char[] arr = str.toCharArray();
        boolean capitalizeNext = true;

        StringBuilder phrase = new StringBuilder();
        for (char c : arr) {
            if (capitalizeNext && Character.isLetter(c)) {
                phrase.append(Character.toUpperCase(c));
                capitalizeNext = false;
                continue;
            } else if (Character.isWhitespace(c)) {
                capitalizeNext = true;
            }
            phrase.append(c);
        }

        return phrase.toString();
    }

    public void savePhone(String mNumber) {
        SharedPreferences.Editor editor = mContext.getSharedPreferences("store", MODE_PRIVATE).edit();
        editor.putString("phone", mNumber);
        editor.apply();
    }
}
