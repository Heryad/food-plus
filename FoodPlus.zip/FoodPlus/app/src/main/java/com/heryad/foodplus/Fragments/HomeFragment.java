package com.heryad.foodplus.Fragments;


import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.heryad.foodplus.Adapters.BannerAdapter;
import com.heryad.foodplus.Adapters.HomeListAdapter;
import com.heryad.foodplus.App.KeyService;
import com.heryad.foodplus.Database.DBHelper;
import com.heryad.foodplus.R;
import com.heryad.foodplus.Utils.BannerItem;
import com.heryad.foodplus.Utils.HomeItem;
import com.smarteist.autoimageslider.IndicatorAnimations;
import com.smarteist.autoimageslider.SliderAnimations;
import com.smarteist.autoimageslider.SliderView;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    private List<HomeItem> restList;
    private HomeListAdapter adapter;
    private BannerAdapter bannerAdapter;
    private List<BannerItem> bannerList;
    private RecyclerView.LayoutManager layoutManager;
    private RecyclerView recyclerView;
    private SliderView banner;
    ProgressBar prg;

    FirebaseDatabase db;

    public HomeFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_home, container, false);

        recyclerView = rootView.findViewById(R.id.homeList);
        recyclerView.setLayoutManager(layoutManager);
        layoutManager = new LinearLayoutManager(getContext());
        prg = rootView.findViewById(R.id.prgHome);
        banner = rootView.findViewById(R.id.imageSlider);

        db = FirebaseDatabase.getInstance();

        fetchBanner();
        return rootView;
    }

    //gets all the data's from the server (Firebase) into the banner
    private void fetchBanner() {
        bannerList = new ArrayList<>();
        db.getReference().getRef().child("system")
                .child("banner")
                .child(getCityName())
                .addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot result : dataSnapshot.getChildren()) {
                    String imgUrl = result.child("url").getValue().toString();
                    String mPurpose = result.child("bannerPurpose").getValue().toString();
                    String mValue = result.child("bannerValue").getValue().toString();
                    bannerList.add(new BannerItem(imgUrl, mValue, mPurpose));
                    bannerAdapter = new BannerAdapter(getContext(), bannerList);
                    banner.setSliderAdapter(bannerAdapter);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        banner.setIndicatorAnimation(IndicatorAnimations.WORM); //set indicator animation by using SliderLayout.IndicatorAnimations. :WORM or THIN_WORM or COLOR or DROP or FILL or NONE or SCALE or SCALE_DOWN or SLIDE and SWAP!!
        banner.setSliderTransformAnimation(SliderAnimations.SIMPLETRANSFORMATION);
        banner.setAutoCycleDirection(SliderView.AUTO_CYCLE_DIRECTION_BACK_AND_FORTH);
        banner.setIndicatorSelectedColor(Color.WHITE);
        banner.setIndicatorUnselectedColor(Color.GRAY);
        banner.setScrollTimeInSec(6); //set scroll delay in seconds :
        banner.startAutoCycle();
        fetchData();
    }

    //gets all the data's back from the server (Firebase) and shows them in list
    private void fetchData() {
        restList = new ArrayList<>();
        prg.setVisibility(View.VISIBLE);
        db.getReference().getRef().child("restaurants").child(getCityName()).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                for (DataSnapshot result : dataSnapshot.getChildren()) {
                    String imgURL = result.child("url").getValue().toString();
                    String restName = result.child("restName").getValue().toString();
                    String deliveryTime = result.child("deliveryTime").getValue().toString();
                    String minOrder = result.child("minOrder").getValue().toString();
                    String workingHours = result.child("workingTime").getValue().toString();

                    restList.add(new HomeItem(imgURL, restName, deliveryTime, minOrder, workingHours));

                    adapter = new HomeListAdapter(getContext(), restList);
                    recyclerView.setLayoutManager(layoutManager);
                    recyclerView.setAdapter(adapter);
                }
                prg.setVisibility(View.GONE);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    public String getCityName()
    {
        DBHelper dbHelper = new DBHelper(getContext());
        Cursor cursor = dbHelper.getLocation();
        String cityName = "";
        if (cursor.getCount() != 0)
        {
            while (cursor.moveToNext())
            {
                 cityName = cursor.getString(1);
            }
        }
        return cityName;
    }

    @Override
    public void onResume() {
        super.onResume();
    }
}
