package com.heryad.foodplus.Adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.heryad.foodplus.App.KeyService;
import com.heryad.foodplus.CategoryActivity;
import com.heryad.foodplus.R;
import com.heryad.foodplus.Utils.HomeItem;

import java.util.List;

public class HomeListAdapter extends RecyclerView.Adapter<HomeListAdapter.DataViewHolder> {

    private Context mContext;
    private List<HomeItem> itemList;

    public HomeListAdapter(Context mContext, List<HomeItem> itemList) {
        this.mContext = mContext;
        this.itemList = itemList;
    }

    @NonNull
    @Override
    public HomeListAdapter.DataViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(
                R.layout.list_item_home, parent, false);
        return new DataViewHolder(view);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull HomeListAdapter.DataViewHolder holder, final int position) {
        Glide.with(mContext).load(itemList.get(position).getImgUrl()).into(holder.imgTitle);

        holder.txtRestName.setText(itemList.get(position).getRestName().toUpperCase());
        holder.txtStatus.setText(itemList.get(position).getWorkingHours().toUpperCase());
        holder.txtDeliveryTime.setText(mContext.getResources().getString(R.string.lbl_pre_time)
                + " " + itemList.get(position).getDeliveryTime()
                + " " + mContext.getResources().getString(R.string.lbl_mins));
        holder.txtMinOrder.setText(mContext.getResources().getString(R.string.lbl_min_order)
                + " " + itemList.get(position).getMinOrder() + " IQD");
        KeyService.minOrder = Integer.parseInt(itemList.get(position).getMinOrder());
        holder.layout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(mContext, CategoryActivity.class);
                intent.putExtra("name", itemList.get(position).getRestName());
                mContext.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    public class DataViewHolder extends RecyclerView.ViewHolder {

        LinearLayout layout;
        ImageView imgTitle;
        TextView txtRestName;
        TextView txtStatus;
        TextView txtDeliveryTime;
        TextView txtMinOrder;

        public DataViewHolder(@NonNull View itemView) {
            super(itemView);
            layout = itemView.findViewById(R.id.lst_home);
            imgTitle = itemView.findViewById(R.id.lst_home_Image);
            txtRestName = itemView.findViewById(R.id.lst_home_restName);
            txtStatus = itemView.findViewById(R.id.lst_home_status);
            txtDeliveryTime = itemView.findViewById(R.id.lst_home_deliveryTime);
            txtMinOrder = itemView.findViewById(R.id.lst_home_minOrder);
        }
    }

}
