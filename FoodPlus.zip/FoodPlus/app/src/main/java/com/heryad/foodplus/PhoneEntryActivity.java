package com.heryad.foodplus;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.heryad.foodplus.App.CustomDialog;
import com.heryad.foodplus.App.KeyService;

public class PhoneEntryActivity extends AppCompatActivity {

    EditText edtPhoneNumber;
    Button btnVerify;

    CustomDialog customDialog;

    FirebaseDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phone_entry);

        edtPhoneNumber = findViewById(R.id.edt_entry_number);
        btnVerify = findViewById(R.id.btn_entry_verify);

        db = FirebaseDatabase.getInstance();

        btnVerify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String phoneNum = edtPhoneNumber.getText().toString();
                if (TextUtils.isEmpty(phoneNum)) {
                    customDialog = new CustomDialog(PhoneEntryActivity.this);
                    String text = PhoneEntryActivity.this.getResources().getString(R.string.msg_fill);
                    String ok = PhoneEntryActivity.this.getResources().getString(R.string.btn_ok);
                    customDialog.showInfoDialog(KeyService.INFO_ICON, text, ok);
                } else {
                    checkDatabase(phoneNum);
                }
            }
        });
    }

    //checks if phone exists or not
    private void checkDatabase(final String mNumber) {
        customDialog = new CustomDialog(PhoneEntryActivity.this);
        customDialog.showLoadingDialog(this.getResources().getString(R.string.msg_wait));
        db.getReference().getRef().child("users")
                .child("erbil")
                .child(mNumber).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    customDialog.dissmisDialog();
                    //sends the user to verification activity
                    Intent intent = new Intent(PhoneEntryActivity.this, PhoneVerificationActivity.class);
                    intent.putExtra("phone", mNumber);
                    startActivity(intent);
                } else {
                    customDialog.dissmisDialog();
                    //sends the user to sign up activity
                    Intent intent = new Intent(PhoneEntryActivity.this, SignUpActivity.class);
                    intent.putExtra("phone", mNumber);
                    startActivity(intent);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
    }

    @Override
    public void onBackPressed() {

    }
}
