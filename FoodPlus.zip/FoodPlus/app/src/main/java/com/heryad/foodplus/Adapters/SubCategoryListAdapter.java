package com.heryad.foodplus.Adapters;

import android.app.Dialog;
import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.heryad.foodplus.App.CustomDialog;
import com.heryad.foodplus.Database.DBHelper;
import com.heryad.foodplus.R;
import com.heryad.foodplus.Utils.SubCategoryItem;

import java.util.List;

import static android.content.Context.LAYOUT_INFLATER_SERVICE;

public class SubCategoryListAdapter extends RecyclerView.Adapter<SubCategoryListAdapter.DataViewHolder> {

    private Context mContext;
    private List<SubCategoryItem> itemList;
    SubCategoryListAdapter.EventListener listener;

    public SubCategoryListAdapter(Context mContext, List<SubCategoryItem> itemList, SubCategoryListAdapter.EventListener listener) {
        this.mContext = mContext;
        this.itemList = itemList;
        this.listener = listener;
    }


    @NonNull
    @Override
    public SubCategoryListAdapter.DataViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(
                R.layout.list_item_subcategory, parent, false);
        return new SubCategoryListAdapter.DataViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull SubCategoryListAdapter.DataViewHolder holder, final int position) {
        Glide.with(mContext).load(itemList.get(position).getImageUrl()).into(holder.imgTitle);
        holder.txtTitle.setText(itemList.get(position).getItemName().toUpperCase());
        holder.txtPrice.setText(mContext.getResources().getString(R.string.lbl_price) + " " + itemList.get(position).getItemPrice() + " IQD");
        holder.btnAddToBasket.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String restName = itemList.get(position).getRestName();
                checkForCart(restName, position);
            }
        });
    }

    public interface EventListener {
        void onEvent();
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    //checks if the cart is empty or not to take action
    private void checkForCart(String restName, int position) {
        DBHelper dbHelper = new DBHelper(mContext);
        Cursor cursor = dbHelper.getCartItems();
        if (cursor.getCount() > 0) {
            while (cursor.moveToNext()) {
                    String dbRestName = cursor.getString(1);
                    if (restName.equals(dbRestName)) {
                        listener.onEvent();
                        addData(position);
                    } else {
                        showDialog(dbRestName, position);
                }
            }
        } else {
            addData(position);
        }
    }

    //notifies the user with yes or no dialog to clear the cart if its not empty
    private void showDialog(String cartRestName, final int position) {
        LayoutInflater inflater = (LayoutInflater) mContext.getSystemService(LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.dialog_cart, null);
        final Dialog dialog = new Dialog(mContext);
        dialog.setContentView(view);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(false);
        dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        TextView txtTitle = view.findViewById(R.id.dialog_title);
        Button btnYes = view.findViewById(R.id.dialog_yes);
        Button btNo = view.findViewById(R.id.dialo_no);

        String dMessage = mContext.getResources().getString(R.string.msg_rest_order) + " " + cartRestName + " " + mContext.getResources().getString(R.string.msg_rest_order_finish);
        txtTitle.setText(dMessage);

        btnYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DBHelper dbHelper = new DBHelper(mContext);
                dbHelper.clearBasket();
                addData(position);
                dialog.dismiss();
                listener.onEvent();
            }
        });
        btNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog.dismiss();
            }
        });
        dialog.show();
    }

    // adds the data to database
    private void addData(int position) {
        DBHelper dbHelper = new DBHelper(mContext);
        dbHelper.addFood(itemList.get(position).getRestName(),
                itemList.get(position).getItemName(),
                itemList.get(position).getItemPrice(),
                itemList.get(position).getImageUrl());
        listener.onEvent();
        CustomDialog customDialog = new CustomDialog(mContext);
        customDialog.showInfoDialog(itemList.get(position).getImageUrl(), itemList.get(position).getItemName() + " Has been added to basket", "Ok");
    }

    public class DataViewHolder extends RecyclerView.ViewHolder {

        ImageView imgTitle;
        TextView txtTitle;
        TextView txtPrice;
        Button btnAddToBasket;

        public DataViewHolder(@NonNull View itemView) {
            super(itemView);
            imgTitle = itemView.findViewById(R.id.lst_subcategory_img);
            txtTitle = itemView.findViewById(R.id.lst_subcategory_title);
            txtPrice = itemView.findViewById(R.id.lst_subcategory_price);
            btnAddToBasket = itemView.findViewById(R.id.lst_subcategory_add);
        }
    }
}